from django.apps import AppConfig


class DjangoEncryptedFilefieldsConfig(AppConfig):
    name = 'django_encrypted_filefield'
